Color codes gamitin niyo kung gusto niyo baguhin ang color scheme:
https://www.w3schools.com/colors/colors_picker.asp
