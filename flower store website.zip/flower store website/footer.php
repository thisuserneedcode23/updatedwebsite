<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>contact info</h3>
            <p> <i class="fas fa-phone"></i> +099-511-76532 </p>
            <p> <i class="fas fa-phone"></i> +099-511-76532 </p>
            <p> <i class="fas fa-envelope"></i> d'hiddenbrew@gmail.com </p>
            <p> <i class="fas fa-map-marker-alt"></i> San Pablo City - 123-456 </p>
        </div>

        <div class="box">
            <h3>follow us</h3>
            <a href="#"><i class="fab fa-facebook-f"></i>@d'hiddenbrew</a>
            <a href="#"><i class="fab fa-twitter"></i>@d'hiddenbrew</a>
            <a href="#"><i class="fab fa-instagram"></i>@d'hiddenbrew</a>
        </div>

    </div>

    <div class="credit">&copy; copyright @ <?php echo date('Y'); ?> by <span>D' Hidden Brew</span> </div>

</section>